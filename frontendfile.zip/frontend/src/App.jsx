import React, { useEffect } from 'react';
import AOS from 'aos';
import 'aos/dist/aos.css';

export default function App() {
  useEffect(() => {
    AOS.init({ duration: 1000, once: true });
  }, []);

  return (
    <>
      {/* Navbar */}
      <header className="fixed top-0 left-0 w-full bg-white shadow-md z-50 px-8 py-4">
  <div className="max-w-7xl mx-auto flex justify-between items-center">
    <h1 className="text-2xl font-bold text-green-700">🌾 AI Farming Assistant</h1>
    <nav className="flex gap-6 font-medium text-gray-800">
      <a href="#home" className="hover:text-green-600">Home</a>
      <a href="#about" className="hover:text-green-600">About</a>
      <a href="#services" className="hover:text-green-600">Services</a>
      <a href="#recommend" className="hover:text-green-600">Assistant</a>
      <a href="#contact" className="hover:text-green-600">Contact</a>
    </nav>
  </div>
</header>


      {/* Hero Section */}
      <section id="home" className="relative h-screen flex flex-col items-center justify-center text-center pt-40 px-4">

        <img
          src="wheat-field.jpg"
          alt="Farming Background"
          className="absolute inset-0 w-full h-full object-cover z-0"
        />
        <div className="absolute inset-0 bg-black bg-opacity-60 z-10"></div>
        <div className="relative z-20 text-white max-w-3xl" data-aos="zoom-in">
          <img src="kid_5348797 (2).png" alt="AI Assistant" className="w-24 h-24 mx-auto mb-6" />
          <h1 className="text-4xl md:text-5xl font-bold">AI Farming Assistant</h1>
          <p className="mt-4 text-xl">
            Empowering farmers with smart, sustainable, and data-driven solutions.
          </p>
          <button className="mt-6 px-6 py-3 bg-green-600 hover:bg-green-700 rounded-lg text-white text-lg transition">
            Get Started
          </button>
        </div>
      </section>

      {/* Recommendation Section */}
      <section id="recommend" className="py-24 px-8 bg-gradient-to-br from-green-300 via-lime-100 to-green-100" data-aos="fade-up">

        <h2 className="text-3xl font-bold text-green-800 mb-10">🌱 AI Recommendation System</h2>
        <div className="max-w-4xl mx-auto space-y-8 bg-white p-10 rounded-2xl shadow-xl border border-green-200">
          <input
            type="text"
            placeholder="Enter Farmer Info - e.g., Tomato crop in dry soil"
            className="w-full p-4 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-400"
          />
          <input
            type="text"
            placeholder="Enter Market Trends - e.g., High demand for organic vegetables"
            className="w-full p-4 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-400"
          />
          <div className="flex justify-center space-x-6 pt-4">
            <button className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg transition flex items-center gap-2">
              <span role="img" aria-label="search">🔍</span>
              <span>Get Recommendation</span>
            </button>
            <button className="bg-gray-300 hover:bg-gray-400 text-gray-800 px-6 py-3 rounded-lg transition flex items-center gap-2">
              <span role="img" aria-label="reset">♻️</span>
              <span>Reset</span>
            </button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 px-8 bg-gradient-to-r from-yellow-200 via-white to-green-100 text-center" data-aos="fade-left">
      <h1 className="text-2xl font-bold text-red-700 bg-red-300">TESTING BACKGROUND</h1>

        <h2 className="text-3xl font-bold mb-6 text-green-800">📌 About Us</h2>
        <p className="text-lg text-gray-700 max-w-2xl mx-auto leading-relaxed">
          Our mission is to enhance agricultural practices using artificial intelligence to deliver productivity,
          sustainability, and profitability. We help farmers make smarter, faster, and more informed decisions.
        </p>
      </section>

      {/* Services Section */}
      <section id="services" className="py-24 px-8 bg-gradient-to-br from-sky-200 via-white to-emerald-100 text-center" data-aos="fade-right">

        <h2 className="text-3xl font-bold mb-10 text-green-800">🚜 Our Services</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-10 max-w-6xl mx-auto">
          <div className="bg-white p-6 rounded-xl shadow-lg" data-aos="zoom-in">
            <h3 className="text-xl font-semibold text-green-700 mb-2">🌿 Crop Advisor</h3>
            <p>Smart crop planning based on soil and climate conditions.</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-lg" data-aos="zoom-in" data-aos-delay="100">
            <h3 className="text-xl font-semibold text-green-700 mb-2">📊 Market Insights</h3>
            <p>Real-time price and demand forecasting for your crops.</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-lg" data-aos="zoom-in" data-aos-delay="200">
            <h3 className="text-xl font-semibold text-green-700 mb-2">🌎 Sustainability Tips</h3>
            <p>Guidance for eco-friendly and efficient farming methods.</p>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 px-8 bg-gradient-to-br from-orange-200 via-white to-rose-100 text-center" data-aos="fade-up">

        <h2 className="text-3xl font-bold text-green-700 mb-6">📬 Contact Us</h2>
        <p className="text-gray-700 mb-4">Let’s build the future of smart farming together.</p>
        <a href="mailto:support@aifarming.com" className="text-blue-600 underline hover:text-blue-800">
          support@aifarming.com
        </a>
        <p className="mt-6 text-sm text-gray-500">
          © 2025 AI Farming Assistant. All rights reserved.
        </p>
      </section>
    </>
  );
}















         

 


