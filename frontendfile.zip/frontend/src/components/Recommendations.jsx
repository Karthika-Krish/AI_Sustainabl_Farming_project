import { useEffect, useState } from 'react';

const Recommendations = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetch('http://127.0.0.1:8000/recommendations')
      .then((res) => res.json())
      .then((resData) => {
        console.log("API Response:", resData);
        setData(resData.data);
      })
      .catch((err) => {
        console.error("Error fetching recommendations:", err);
      });
  }, []);

  return (
    <div className="p-6 bg-white rounded shadow-md">
      <h2 className="text-xl font-bold mb-4">📋 Past Recommendations</h2>
      {data.length === 0 ? (
        <p>No details found.</p>
      ) : (
        <ul className="space-y-4">
          {data.map((item) => (
            <li key={item[0]} className="p-4 border rounded-md">
              <p><strong>🧑‍🌾 Farmer Input:</strong> {item[1]}</p>
              <p><strong>📊 Market Trends:</strong> {item[2]}</p>
              <p><strong>💡 Recommendation:</strong></p>
              <div className="whitespace-pre-line bg-gray-100 p-2 rounded mt-1">{item[3]}</div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default Recommendations;
