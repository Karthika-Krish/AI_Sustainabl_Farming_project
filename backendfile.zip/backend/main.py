# main.py
from fastapi.responses import RedirectResponse

from fastapi import FastAPI
from pydantic import BaseModel

from fastapi.middleware.cors import CORSMiddleware
import time

import sqlite3
import ollama

import pandas as pd

# Load CSV datasets
farmer_df = pd.read_csv("Farmer_Advisor.csv")
market_df = pd.read_csv("Market_Researcher.csv")

# You can do more advanced logic, but here’s a quick useful summary
most_common_crop = farmer_df["Crop_Type"].value_counts().idxmax()
top_market_crop = market_df["Product"].value_counts().idxmax()


app = FastAPI()

# ✅ Add CORS middleware here (only once)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ✅ Add this warm-up code right after app is created
@app.on_event("startup")
def warmup_model():
    print("🔥 Warming up the model...")
    try:
        ollama.chat(model="gemma:2b", messages=[{"role": "user", "content": "Say hello"}])
        print("✅ Model is ready!")
    except Exception as e:
        print("⚠️ Model warm-up failed:", e)

 
conn = sqlite3.connect("recommendations.db", check_same_thread=False)
cursor = conn.cursor()
cursor.execute("""
CREATE TABLE IF NOT EXISTS recommendations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    farmer_input TEXT,
    market_trends TEXT,
    ai_recommendation TEXT
)
""")
conn.commit()

class RecommendationRequest(BaseModel):
    farmer_input: str
    market_trends: str
  
@app.post("/recommend")
async def recommend(request: RecommendationRequest):
    try:
        start = time.time()  # ⏱️ Start timer
        print("🔄 Received request, starting recommendation process...")

        farmer_input = request.farmer_input
        market_trends = request.market_trends

        prompt = f"""
Farmer Info: {farmer_input}
Market Trends: {market_trends}

📊 Based on historical data:
- Most commonly recommended crop: {most_common_crop}
- Most trending crop in market: {top_market_crop}

✅ Give a smart, sustainable farming recommendation considering the input and data.
"""

        response = ollama.chat(model="gemma:2b", messages=[
            {"role": "user", "content": prompt}
        ])
        result = response['message']['content']

        cursor.execute("INSERT INTO recommendations (farmer_input, market_trends, ai_recommendation) VALUES (?, ?, ?)",
                       (farmer_input, market_trends, result))
        conn.commit()

        elapsed = round(time.time() - start, 2)  # ⏱️ End timer
        print(f"✅ Recommendation done in {elapsed} seconds")

        return {"recommendation": result}
    
    except Exception as e:
        print("🔥 ERROR:", e)
        return {"error": str(e)}
    print("🔥 TEST")

 
 
@app.get("/recommendations")
def get_recommendations():
    cursor.execute("SELECT * FROM recommendations ORDER BY id DESC")
    data = cursor.fetchall()
    return {"data": data}

from pydantic import BaseModel

class QueryRequest(BaseModel):
    question: str

@app.post("/ask")
async def ask_question(req: QueryRequest):
    question = req.question
    # Use the installed model: gemma:2b
    response = ollama.chat(model="gemma:2b", messages=[
        {"role": "user", "content": question}
    ])
    result = response['message']['content']
    return {"response": result}


class CropInput(BaseModel):
    Soil_pH: float
    Soil_Moist: float
    Temperature: float
    Rainfall_mm: float
    Fertilizer_kg: float
    Pesticide_kg: float
    Crop_Yield: float
    Sustainability_Score: float

@app.post("/recommend_crop")
async def recommend_crop(data: CropInput):
    try:
        score_map = {}
        for _, row in market_df.iterrows():
            crop = row["Product"]
            demand = row["Demand_Index"]
            price = row["Market_Price_per_ton"]
            trend = row["Consumer_Trend_Index"]
            
            score = (demand * 0.4) + (price * 0.4) + (trend * 0.2)
            score_map[crop] = score

        best_crop = max(score_map, key=score_map.get)
        
        return {
            "Recommended Crop": best_crop,
            "Market_Price": market_df[market_df["Product"] == best_crop]["Market_Price_per_ton"].values[0],
            "Demand_Index": market_df[market_df["Product"] == best_crop]["Demand_Index"].values[0],
            "Consumer_Trend_Index": market_df[market_df["Product"] == best_crop]["Consumer_Trend_Index"].values[0],
            "Final Score": round(score_map[best_crop], 2)
        }
    except Exception as e:
        print("🔥 ERROR:", e)
        return {"error": str(e)}


@app.get("/", include_in_schema=False)
def root():
    return RedirectResponse(url="/docs")
